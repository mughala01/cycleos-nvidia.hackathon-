Render deployment
1. Upload app.py and requirements.txt to your public GitHub repository.
2. Render > New > Web Service > connect the repository.
3. Language: Python. Build command: pip install -r requirements.txt
4. Start command: python app.py
5. Instance type: Free.
6. Environment variable: NEBIUS_API_KEY = your private Nebius key. NEVER add the key to GitHub.
7. Deploy and test using synthetic data.

WARNING: The free service filesystem is temporary and this demo has shared server-side history. Do not enter real personal or sensitive information. The app can sleep and take time to restart.
